<?php

include ("includes/header.php");
include ("includes/_functions.php");//addEmoticons & makeClickableLinks here
$author = $_GET['author'];
$result2 = mysqli_query($con, "SELECT * FROM users where user_id = '$author' ");
while($row = mysqli_fetch_array($result2)){
	$user_name = $row['user_name'];
}
?>
	
	<h3>Other photos by <?php echo $user_name ?></h3>
<?php
	
	$result1 = mysqli_query($con, "SELECT * FROM mugallery WHERE author_id = '$author'") or die(mysqli_error($con));
				while($row = mysqli_fetch_array($result1)):
				$img_id = $row['img_id'];

 ?>

				<div class=" col-lg-2">
					<div class="title"><?php echo nl2br(addEmoticons($row['img_title']));?></div>
					<div class="thumb"><a href="display.php?id=<?php echo $img_id; ?>&author=<?php echo $author ?>"><img src="thumbs/<?php echo $row['file_name'] ?>"></a> </div>		
				</div>	


			<?php endwhile; ?>
	
</div>

<?php



include ("includes/footer.php");
?>