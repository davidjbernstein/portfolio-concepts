<?php

include ("includes/header.php");
include ("includes/_functions.php");//addEmoticons & makeClickableLinks here
?>
<div class="row">
	<div class="col-md-12">
		<h1><?php echo APP_NAME; // see includes/mysql_connect for this constant ?></h1>
		<div class="col-md-9">
<?php

//////////// pagination
$getcount = mysqli_query ($con,"SELECT COUNT(*) FROM mublog");
$postnum = mysqli_result($getcount,0);// this needs a fix for MySQLi upgrade; see custom function below


// MySQLi upgrade: we need this for mysql_result() equivalent
function mysqli_result($res, $row, $field=0) { 
    $res->data_seek($row); 
    $datarow = $res->fetch_array(); 
    return $datarow[$field]; 
}


$result1 = mysqli_query($con, "SELECT * FROM users ORDER BY user_id DESC ");


// $result = mysqli_query($con, "SELECT * FROM mublog JOIN users ON mublog.author_id = users.user_id ORDER BY bid DESC $limstring");
?>

<?php while($row = mysqli_fetch_array($result1)): 
	$user_id = $row['user_id'];

?>
	<!-- Go ahead and do some HTML/CSS styling in here...I dare you! -->

<div class="blog-entry">
	<div class="row">
		<div class="col-md-12">
			<h3 class="title"><?php echo $row['user_name']; ?></h3>
			<?php 
				$result2 = mysqli_query($con, "SELECT * FROM mugallery WHERE author_id = '$user_id'");
			?>
			<div class="row">
			<?php while($row = mysqli_fetch_array($result2)):
			$img_id = $row['img_id'];
	// echo "$img_id"; ?>

				<div class="col-lg-2">
					<div class="title"><?php echo nl2br(addEmoticons($row['img_title']));?></div>
					<div class="thumb"><a href="display.php?id=<?php echo $img_id; ?>&author=<?php echo $user_id ?>"><img src="thumbs/<?php echo $row['file_name'] ?>"></a> </div>		
				</div>	


			<?php endwhile; ?>
			</div>

		</div>
		<div class="col-md-6">
			<div class="timedate pull-right">
			<?php 
				// $date = strtotime($row['timedate']); fixes niggly MySQL to PHP date problem 
				// echo date("F j, Y - g:i a", $date);
			?>
			</div>
		</div>
	</div>
	<!-- In this PHP block, we make calls to functions stored elsewhere in our code. 
	If we like using certain functions in our projects, let's make an include out of them, and move them to /includes/ folder.
	-->
	<div class="message"><?php echo nl2br(addEmoticons($row['message']));?></div>
</div>
<div class="label label-warning pull-right"><?php echo "$user_id" ; ?></div>
<?php endwhile; ?>

<div class="pagination-block">
<?php 

///////////////// pagination links
// if you don't like the formatting, feel free to change. Look into Bootstrap Pagination


 ?>
</div><!-- / pagination -->


</div>
    <div id="sideDisplay" class="col-md-3 pull-right">
        <?php
        include("sidebar.php");
        ?>

    </div>
	</div><!--  / col-md-12 -->
</div><!-- / row -->

<?php



include ("includes/footer.php");
?>