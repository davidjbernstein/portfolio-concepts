<?php

include ("includes/header.php");
include ("includes/_functions.php");//addEmoticons & makeClickableLinks here
require ("../login/classes/Login.php");
$login = new Login();
$rater_id = $_SESSION['user_id'];
?>

<div>
	<a href="index.php">Go back</a>
</div>
<div class="col-lg-6">
<?php 

		$id = $_GET['id'];
		$author = $_GET['author'];
		
		$rating = mysqli_query($con,"SELECT * FROM mugallery_ratings WHERE picture_id = '$id' AND rater_id = '$rater_id' ");
		$rowcount = mysqli_num_rows($rating);
		echo "$rowcount $id $rater_id";
		if($rowcount == 0){
		if (isset($_SESSION['user_id'])){
			echo "<p> rate this picture</p>";
		include("ratingsform.php");
		}
		}else{
		echo "<p>You have already rated this picture</p>";
		}
		
		$result2 = mysqli_query($con, "SELECT * FROM mugallery JOIN users ON mugallery.author_id = users.user_id WHERE img_id = '$id'") or die(mysqli_error($con));
		while($row = mysqli_fetch_array($result2)){



		$filename = $row['file_name'];
		$title = $row['img_title'];
		$id = $row['image_id'];
		$user_name = $row['user_name']; 

		}
		echo "
		<h1>$title by $user_name</h1>
		<p>$description</p>
		<img src=\" display/$filename \" title=\"$title \">
		 
		";
?>
</div>
<div class="col-lg-2 pull-right">
	<?php 
		// $result3 = mysqli_query($con, "SELECT * FROM users WHERE user_id = '$author'") or die(mysqli_error($con));
		// while($row = mysqli_fetch_array($result3)){
			
		// }

	?>
	<h3>Other photos by <?php echo $user_name ?></h3>
<?php
	$result1 = mysqli_query($con, "SELECT * FROM mugallery WHERE author_id = '$author'") or die(mysqli_error($con));
				while($row = mysqli_fetch_array($result1)):
				$img_id = $row['img_id'];

 ?>

				<div class=" col-lg-12">
					<div class="title"><?php echo nl2br(addEmoticons($row['img_title']));?></div>
					<div class="thumb"><a href="display.php?id=<?php echo $img_id; ?>&author=<?php echo $author ?>"><img src="thumbs/<?php echo $row['file_name'] ?>"></a> </div>		
				</div>	


			<?php endwhile; ?>
	
</div>
<?php
include ("includes/footer.php");
?>