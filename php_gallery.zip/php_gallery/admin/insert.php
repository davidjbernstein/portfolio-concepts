<?php
require ("../login/classes/Login.php");

$login = new Login();


if($login->isUserLoggedIn() == true){
	include("../includes/header.php");
	echo "welcome" . $_SESSION['user_name'] . "your ID is " . $_SESSION['user_id'];
	$author_id = $_SESSION['user_id'];

}
else{
	include("../includes/mysql_connect.php");
	header("location: http://dbernstein1.dmitstudent.ca/dmit2503/mubgallery/index.php");

}

// AUTH



?>
<div class="row">
	<div class="col-md-6">
<h2>Insert</h2>


	<div class="panel panel-default">
		  <div class="panel-heading">New Blog Entry</div>
		  <div class="panel-body">
		  

	<form id="myform" name="myform" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">
		<div class="form-group">
			<label for="title">Title</label>
			<input type="text" name="title" class="form-control" value="<?php echo $title ?>">
			<?php
			if($valTitle != ""){
				echo "<div class=\"alert alert-danger\">$valTitle</div>";
			} 
			?>
		</div>		
		<div class="form-group">
			<label for="myfile">Photo</label>
			<input type="file" name="myfile">
		</div>


		<div class="form-group">
			<label for="submit">&nbsp;</label>
			<input type="submit" name="submit" class="btn btn-info" value="Submit">
		</div>
	</form>

	</div>
</div><!-- /panel -->

<?php
if(isset($_POST['submit'])){
	// trim(): removes spaces before or after a string




	$title = strip_tags(trim($_POST['title']));
	// $unique = uniqid();

	//echo "$fname, $lname, $description";

	// assume the form is filled out correctly, and set a boolean
	$boolValidateOK = 1;
	$strValidationMessage = "";

	// VALIDATION RULES

	// Name

	if((strlen($title ) < 2) || (strlen($title ) > 50)){
		$boolValidateOK = 0;
		$valTitle = "Please fill in a proper Title from 2 to 50 characters.<br>";
	}

	


	 if($_FILES['myfile']['type'] == "image/jpeg" ){

	    }
	    else {
	      $boolValidateOK = 0;
	      $strValidationMessage .= "That is not a JPEG image.<br>";
	    }


	    //size 
	    if($_FILES['myfile']['size'] > 5242880) {
	      $boolValidateOK = 0;
	      $strValidationMessage .= "File cannot be bigger than 5mb";
	    }
	    // If succeed
	    if($boolValidateOK == 1){
	      $filename = $_FILES['myfile']['name'];
	      if(move_uploaded_file($_FILES['myfile']['tmp_name'], "../originals/" . $filename)){

	           $thisFile = "../originals/". $filename;
	           
	         resizeImage($thisFile, "../thumbs/", 170); // $file, $folder, $newwidth
	         resizeImage($thisFile, "../display/", 800);

	         		mysqli_query($con, "INSERT INTO mugallery (author_id, img_title, file_name) VALUES ('$author_id' ,'$title','$filename')") or die(mysqli_error($con));


					$valSuccess= "Entry Added";
					
					$title = "";
					$entry = "";

	        


	        echo "SUCCESS";
	        

	      } else {

	        echo "SOMETHING WENT WRONG";
	      }


	    } else {
	        echo $strValidationMessage;

	    } //  END ELSE
		



}// \ if submit

function resizeImage($file, $folder, $newwidth) {

    list($width, $height) = getimagesize($file);
    $imgRatio = $width/$height;




    // echo "$width | $height | $imgRatio";


    $newheight = $newwidth/$imgRatio;

    $thumb = imagecreatetruecolor($newwidth, $newheight);
    $source = imagecreatefromjpeg($file);

    imagecopyresampled($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);


    // create output path filename

    $newFilename = $folder . $_FILES['myfile']['name'];


    imagejpeg($thumb, $newFilename, 150);

    imagedestroy($thumb);
    imagedestroy($source);

  }

?>
<?php
if($valSuccess != ""){
	echo "<div class=\"alert alert-warning\">$valSuccess</div>";
} 
?>
	</div>
</div><!-- / row -->



<?php
	include("../includes/footer.php");
?>