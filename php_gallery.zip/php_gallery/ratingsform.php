<?php 
   $pic_id = $_GET['id'];
if(isset($_POST['submit'])){ 
    $rating = strip_tags(trim($_POST['star']));
 
    $boolValidateOK = 1;

    if( $rating == ""){
        $boolValidateOK = 0;
    }

    if($boolValidateOK == 1){
        mysqli_query($con, "INSERT INTO mugallery_ratings (picture_id, rating, rater_id) VALUES ('$pic_id' ,'$rating','$rater_id')") or die(mysqli_error($con));
        echo "succeed";
        header("location:" . BASE_URL . "display.php?id=" . $id . "&author=" . $author . ".php");
    }

}
?>

<form id="ratingsForm" name="myform" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
  <div class="stars">
    <input type="radio" name="star" class="star-1" value="1" id="star-1">
    <label class="star-1" for="star-1">1</label>
    <input type="radio" name="star" class="star-2" value="2" id="star-2">
    <label class="star-2" for="star-2">2</label>
    <input type="radio" name="star" class="star-3" value="3" id="star-3">
    <label class="star-3" for="star-3">3</label>
    <input type="radio" name="star" class="star-4" value="4" id="star-4">
    <label class="star-4" for="star-4">4</label>
    <input type="radio" name="star" class="star-5" value="5" id="star-5">
    <label class="star-5" for="star-5">5</label>
    <span></span>
  </div>
    <label for="submit">&nbsp;</label>
    <input type="submit" name="submit" class="btn btn-info" value="Submit">
</form>
