<h2>Featured Images</h2>
<?php
require("includes/mysql_connect.php");
$result1 = mysqli_query($con, "SELECT * FROM mugallery ORDER by rand() LIMIT 4") or die(mysqli_error($con));
while($row = mysqli_fetch_array($result1)):
    $img_id = $row['img_id'];
    $author = $row['author_id'];

    ?>

    <div class=" col-lg-12">
        <div class="title"><?php echo nl2br($row['img_title']);?></div>
        <div class="thumb"><a href="display.php?id=<?php echo $img_id; ?>&author=<?php echo $author ?>"><img src="thumbs/<?php echo $row['file_name'] ?>"></a> </div>
    </div>


<?php endwhile; ?>